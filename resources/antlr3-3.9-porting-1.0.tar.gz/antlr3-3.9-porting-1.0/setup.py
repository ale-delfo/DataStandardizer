from distutils.core import setup

setup(name='antlr3-3.9-porting',
      version='1.0',
      packages=['antlr3'],
     )